# Handoff: Lootix — Full Site Redesign (getlootix.com)

## Overview
Complete redesign of getlootix.com: a fantasy-streetwear brand where every order earns entries into a live-drawn giveaway ("shop-to-win" sweepstakes model, same legal shape as 80eighty.com / Tuner Cult). Nine pages: Home, Shop, Product detail, Giveaway, How It Works, Winners, FAQ, About, Official Rules — plus a shared sticky header and footer.

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — high-fidelity prototypes showing intended look and behavior, **not production code to copy directly**. Recreate these designs in the target codebase's environment (e.g. Next.js on Vercel, deployed via GitHub) using its established patterns. If no environment exists yet, Next.js + React is the recommended choice given the Vercel deployment target. The templates use a custom component syntax (`<sc-for>`, `<sc-if>`, `{{ path }}` holes, `<dc-import>`); read them as JSX-like markup — all styling is inline and translates 1:1 to React style props or Tailwind.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final-intent. Recreate pixel-perfectly. Exceptions (placeholders, clearly marked in the designs):
- Product photos are drag-and-drop `<image-slot>` placeholders — swap for real product photography.
- Entry counts, prices, the countdown target (Aug 15, 2026 8:00 PM ET), and the entries-claimed progress (312/1,000) are sample data — wire to real commerce/sweepstakes data.
- Official Rules copy is structural placeholder — **must be replaced by attorney-reviewed language before launch.**

## Design Tokens
Colors:
- Background: `#0D0B08` (page), `#0A0806` (alt sections/panels), `#100D08` (cards), `#080604` (announce bar/footer)
- Gold accent: `#C9A45C` (primary CTA fill, chips, rules)
- Cream headline: `#F0E6CE`; cream text: `#E8DCC2`
- Body text: `#A79878`; muted: `#8F8168`; dim: `#6E6250`
- CTA text on gold: `#14100A`
- Borders: `rgba(201,164,92,.14)` hairlines; `.2–.45` for interactive borders; solid `#C9A45C` for highlighted cards
- Progress bar: `linear-gradient(90deg,#8a6c33,#C9A45C)`
- Selection: gold bg, `#14100A` text

Typography (Google Fonts):
- Display: **Cinzel** 500/600/700 — all headings, prices, countdown digits, stat numbers
- UI/body: **Archivo** 400/500/600/700
- Nav/eyebrow/labels: 10–13px, uppercase, letter-spacing `.12em–.24em`
- H1: clamp(48px, 4.6vw, 68px) home; 42–52px inner pages. H2: 30–36px. Body: 13.5–16.5px, line-height 1.7–1.85

Spacing & shape:
- Max content width 1360px, 32px side padding; section padding 72–96px vertical
- **No border radius anywhere** (sharp corners are intentional brand language); the only circles are status dots and the cart badge
- No shadows — hierarchy via hairline borders + background steps
- Buttons: gold fill (`#C9A45C`, uppercase 12–13px/700, ls .14em, padding ~15px 30px; hover → `#E8DCC2`) and ghost outline (`rgba(201,164,92,.45)` border; hover → gold border + `rgba(201,164,92,.08)` bg)
- Card hover: border → `rgba(201,164,92,.45)`, translateY(-3px), .25s

## Screens
Each file is one route. Shared: sticky header (announce bar + nav w/ active-link gold underline + gold "Enter the Vault" CTA + cart) and footer (5-badge trust strip, 4-col links, compliance fine print).

- **Home.dc.html** — split hero (copy left; brand photo right with overlaid prize card: $250 + bundle, live countdown, entries progress bar), 4-stat strip, featured drop (4 product cards), "Quick loot" impulse row (low-cost items = quick entries), 3-step How It Works band, Launch Vault section (photo + 3 entry-pack rows, "Hero Bundle $75/150 entries" highlighted), winners/draw-proof split, email capture ("Join the Guild", 25 bonus entries).
- **Shop.dc.html** — page header w/ entries banner, category tab row, 4-col product grid (8 items; every card shows "⛨ Earns N entries" chip top-left; optional tag e.g. "Best seller" stacked below at top:44px), bundle-upsell banner.
- **Product.dc.html** — 2-col PDP: image gallery (main + 4 thumbs) left; right: eyebrow, title, price + rating, highlighted gold entries panel ("This tee earns 60 entries" + draw close link), size selector (S–3XL, selected = gold fill), add-to-cart ("Add to cart — $42 · +60 entries" → "✓ Added — 60 entries secured"), trust ticks, 3 accordions (details, how entries work, shipping/returns).
- **Giveaway.dc.html** — hero with brand photo bg, live badge, big countdown (84px cells), progress bar, dual CTAs; 3 info cards (What you win / How to enter / The draw); 3 entry-pack pricing cards (center card gold-bordered "Most popular"); compliance footnote.
- **How It Works.dc.html** — centered intro, 3 numbered rows (01/02/03) with entry-count chips (Tee 60 / Hoodie 150 / Legend Vault 350 / Quick loot 10–45), two compliance cards (Free entry AMOE, two-track fulfillment), closing CTA.
- **Winners.dc.html** — "vault unclaimed" hero; 3 vault cards (Unclaimed "— Your Name —" highlighted; $1K Club and Legend Status locked at 75% opacity); draw-promise panel (recorded live ≤48h, independent administration, paid fast).
- **FAQ.dc.html** — two accordion groups (Giveaway; Orders & shipping), Official Rules cross-link card.
- **About.dc.html** — photo hero, story split, 4-value grid, contact/CTA close.
- **Official Rules.dc.html** — numbered legal sections 01–09 (eligibility, period, purchase entry, AMOE, prize, selection, publicity, refunds, general). Attorney placeholder notice at top.

## Interactions & Behavior
- Countdown (Home hero + Giveaway): ticks every second to Aug 15 2026 20:00 ET, zero-padded, floors at 00.
- Header: sticky, backdrop-blur; active nav link gets `#E8DCC2` color + 2px gold underline.
- Size selector and add-to-cart are local state; email subscribe button flips to "✓ In the Guild".
- Accordions are native `<details>`; hover states as listed in tokens.
- Every legal footnote links to Official Rules; "no purchase necessary" appears near every entry-related CTA — keep this in production.

## State Management (production)
- Live giveaway: prize, close datetime, entries claimed/goal → drives countdown + progress everywhere.
- Products: name, price, fixed entry count (displayed on card, PDP, cart), edition size, category, tag.
- Cart: line items + summed entries (show entries in cart/receipt).
- Winners: list of past draws (video URL, administrator confirmation, winner name w/ permission) — page currently shows the zero-winners state.

## Assets (in `assets/`)
Crops from the client's brand board (`uploads/photography-1784151946168.png`): `hero-models.png` (hoodie models — Home hero), `tags.png` (hang tags — Giveaway hero, PDP thumb), `unbox.png` (welcome box — Home vault, About), `shoebox.png` (About hero), `wrap.png` (packaging — PDP thumb, sticker card), `logo.png` (script logotype, header/footer), `monogram.png` (gold L mark). Fonts via Google Fonts (Cinzel, Archivo).

## Files
- `Site Header.dc.html`, `Site Footer.dc.html` — shared components (header takes an `active` prop)
- `Home.dc.html`, `Shop.dc.html`, `Product.dc.html`, `Giveaway.dc.html`, `How It Works.dc.html`, `Winners.dc.html`, `FAQ.dc.html`, `About.dc.html`, `Official Rules.dc.html`
- `image-slot.js` — placeholder image component used by the prototypes (do not port; replace with real images)
